 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.0
*/

/*
? [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "AVR128Dx_TFT_LCD.h"
#include "MCP79411.h"
#include <stdio.h>
#include <math.h>

volatile unsigned char      I2C_Wbuffer[16];   
volatile unsigned char      I2C_Rbuffer[16] ;
unsigned char                 ASCII_Buffer[20];

volatile   time_t getTime, setTime;
struct      tm *tm_t;

volatile bool bRTCOverflow = 0 ;
unsigned char   LCD_String[32];
unsigned char   Second = 0 ;
unsigned char   Minute = 0 ;
unsigned char   Hour = 0 ;
unsigned char   SecondCount = 0 ;

unsigned int    LineX ;
float          PositionX = 0 ;

/*
    Main application
*/

void    Draw_Sinwave_Single(float , unsigned int);

void RTC_OVF_Callback(void){
    bRTCOverflow = 1 ;
}

int main(void)
{
    SYSTEM_Initialize();
    RTC_SetOVFIsrCallback(RTC_OVF_Callback);
    MCP79411_Initialize();
    
    DELAY_milliseconds(200);      
    SPI0_Host_Open(HOST_CONFIG);
    
    Lcd_Init();
    DELAY_milliseconds(200);    
    LCD_Clear(GREEN);
    DELAY_milliseconds(500);
    LCD_Clear(BLACK);
    
    LCD_Fill(0,130,127,139,RED);
    LCD_Fill(0,140,127,149,WHITE);
    LCD_Fill(0,150,127,159,BLUE);
    
// Display the 16x16 example characters     
    showhanzi16(48, 0, 3);           // 時
    showhanzi16(64, 0, 4);          // 間
   
    showhanzi16(0, 48,0);           // 電
    showhanzi16(16, 48,1);          // 壓    
    showhanzi16(32, 48,0);          // 電
    showhanzi16(48, 48,2);          // 流    
    showhanzi16(64, 48,5);           // 分
    showhanzi16(80, 48,6);          // 秒    
    showhanzi16(96, 48,7);          // 溫
    showhanzi16(112, 48,8);          // 度
    
    POINT_COLOR = RED ;
    LCD_DrawRectangle(18,78, 112, 122);
    
//    //  *********************************************************************************
//    //  使用 mktime 取得時間秒數，並且使用 MCP411_SetTime 來設定所需要的時間的範例
//    //  *********************************************************************************   
//            getTime = MCP79411_GetTime();
//            tm_t = localtime(&getTime);                
//            tm_t->tm_year = 2024-1900 ;
//            tm_t->tm_mon = 1 ;                  //  Febryary ( month 0:11)
//            tm_t->tm_mday = 11 ;               // mday (1~31)
//            tm_t->tm_hour = 9 ;
//            tm_t->tm_min = 27 ;
//            tm_t->tm_sec = 30 ;
//            setTime =  mktime(tm_t) ;
//           MCP79411_SetTime(setTime);
    
    while(1)
    {        
        if (bRTCOverflow)
        {
            getTime = MCP79411_GetTime();
            tm_t = localtime(&getTime);
            sprintf (ASCII_Buffer,"Date:%04d-%02d-%02d", tm_t->tm_year+1900, tm_t->tm_mon+1, tm_t->tm_mday) ;
            LCD_ShowString(0, 16, ASCII_Buffer); 
            sprintf (ASCII_Buffer,"Time:%02d:%02d:%02d", tm_t->tm_hour, tm_t->tm_min, tm_t->tm_sec) ;
            LCD_ShowString(0, 32, ASCII_Buffer); 

            LED3_Toggle();         
            Draw_Sinwave_Single(PositionX , 60) ;
            PositionX += 60 ;
            if (PositionX >360)
                PositionX = 60 ;
            
            POINT_COLOR = RED ;                     // 設定畫筆顏色 = RED
            LCD_DrawLine(18,100, 112, 100);
            LCD_DrawLine(64,78, 64, 122);
            POINT_COLOR = WHITE ;               // 重設畫筆顏色 = 白色
            bRTCOverflow = 0;
        }
        
    }    
}

void    Draw_Sinwave_Single(float CurrentX, unsigned int Stepping)
{
    double StartX ;
    POINT_COLOR = BLACK ;
    StartX =  CurrentX ;  
    for (LineX = 19 ; LineX < 110; LineX ++)
    {
        LCD_DrawPoint(LineX, 100 + 20 *(sin((StartX/180 )* 3.1416))) ;
        StartX += 4 ;
        if (StartX >360)
            StartX = 0 ;
    }
    
    POINT_COLOR = GREEN ;
    StartX =  CurrentX+Stepping ;
            if (StartX >360)
            StartX = Stepping ;
    for (LineX = 19 ; LineX < 110; LineX ++)
    {
        LCD_DrawPoint(LineX, 100 + 20 *(sin((StartX/180 )* 3.1416))) ;
        StartX += 4 ;
        if (StartX >360)
            StartX = 0 ;
    }    
    
    POINT_COLOR = WHITE ;
}

